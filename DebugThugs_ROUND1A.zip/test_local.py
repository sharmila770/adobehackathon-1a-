#!/usr/bin/env python3
"""
Local testing script for the Adobe PDF CLI tool.
Creates test directories and runs the tool locally.
"""

import os
import sys
import tempfile
import shutil
from pathlib import Path

# Add current directory to path to import main
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from main import PDFProcessor


def create_test_environment():
    """Create a temporary test environment with input/output directories."""
    # Create temporary directory
    temp_dir = Path(tempfile.mkdtemp(prefix="adobe_pdf_test_"))
    
    # Create input and output directories
    input_dir = temp_dir / "input"
    output_dir = temp_dir / "output"
    
    input_dir.mkdir(exist_ok=True)
    output_dir.mkdir(exist_ok=True)
    
    print(f"Created test environment at: {temp_dir}")
    print(f"Input directory: {input_dir}")
    print(f"Output directory: {output_dir}")
    
    return temp_dir, input_dir, output_dir


def test_with_local_dirs():
    """Test the PDF processor with local directories."""
    temp_dir, input_dir, output_dir = create_test_environment()
    
    try:
        # Create a custom processor with local directories
        class LocalPDFProcessor(PDFProcessor):
            def __init__(self, input_path, output_path):
                self.input_dir = Path(input_path)
                self.output_dir = Path(output_path)
        
        processor = LocalPDFProcessor(input_dir, output_dir)
        
        print("\nPlace your test PDF files in the input directory:")
        print(f"  {input_dir}")
        print("\nPress Enter to continue with processing...")
        input()
        
        # Process PDFs
        processor.process_all_pdfs()
        
        print(f"\nResults saved to: {output_dir}")
        print("Contents:")
        for file in output_dir.glob("*.json"):
            print(f"  - {file.name}")
        
        print(f"\nTest environment will remain at: {temp_dir}")
        print("You can examine the results manually.")
        
    except Exception as e:
        print(f"Error during testing: {e}")
        # Clean up on error
        shutil.rmtree(temp_dir, ignore_errors=True)


if __name__ == "__main__":
    print("Adobe PDF CLI Tool - Local Test")
    print("=" * 40)
    test_with_local_dirs()
