# Adobe PDF CLI Tool - Connecting the Dots Challenge

A command-line Python tool for extracting document titles and headings from PDF files using PyMuPDF.

## Features

- **Title Extraction**: Identifies the document title as the largest font text on page 1
- **Heading Detection**: Extracts H1, H2, H3 headings based on font size and boldness
- **Batch Processing**: Processes multiple PDF files from `/app/input/`
- **JSON Output**: Structured output saved as `{filename}.json` in `/app/output/`
- **Performance**: Optimized to process 50-page PDFs in ≤10 seconds
- **Offline**: No internet connection required
- **Docker Ready**: Compatible with Docker on `linux/amd64`

## Requirements

- Python 3.11+
- PyMuPDF (fitz) 1.23.14

## Installation

### Local Development
```bash
pip install -r requirements.txt
```

### Docker
```bash
# Build the Docker image
docker build -t adobe-pdf-cli .

# Run with mounted volumes
docker run -v /path/to/input:/app/input -v /path/to/output:/app/output adobe-pdf-cli
```

## Usage

### Directory Structure
```
/app/
├── input/          # Place PDF files here
├── output/         # JSON results will be saved here
└── main.py         # CLI tool
```

### Running the Tool
```bash
python main.py
```

### Output Format
```json
{
  "title": "Document Title",
  "outline": [
    { "level": "H1", "text": "Introduction", "page": 1 },
    { "level": "H2", "text": "Background", "page": 2 },
    { "level": "H3", "text": "Methodology", "page": 3 }
  ]
}
```

## Heading Detection Algorithm

The tool uses a sophisticated scoring system to identify headings:

1. **Font Size Analysis**: Compares font sizes against document average
2. **Bold Detection**: Gives bonus points for bold text
3. **Relative Sizing**: Considers font size relative to document maximum
4. **Level Classification**: 
   - H1: Score ≥ 2.0
   - H2: Score ≥ 1.7
   - H3: Score ≥ 1.3

## Performance Optimizations

- Two-pass processing for statistical analysis
- Efficient font information extraction
- Minimal memory footprint
- Fast text block processing

## Docker Compatibility

- Platform: `linux/amd64`
- Offline execution (no internet required)
- All dependencies pre-installed
- Optimized for container environments
