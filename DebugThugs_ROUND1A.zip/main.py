#!/usr/bin/env python3
"""
Adobe "Connecting the Dots" Challenge - Round 1A
CLI tool for extracting document titles and headings from PDF files.
"""

import os
import json
import sys
import time
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import fitz  # PyMuPDF


class PDFProcessor:
    """Processes PDF files to extract titles and headings."""
    
    def __init__(self):
        self.input_dir = Path("/app/input")
        self.output_dir = Path("/app/output")
        
    def ensure_directories(self):
        """Ensure input and output directories exist."""
        self.output_dir.mkdir(parents=True, exist_ok=True)
        if not self.input_dir.exists():
            print(f"Error: Input directory {self.input_dir} does not exist")
            sys.exit(1)
    
    def get_font_info(self, block: Dict) -> Tuple[str, float, bool]:
        """Extract font information from a text block."""
        if "lines" not in block:
            return "", 0.0, False
            
        # Get font info from the first span of the first line
        for line in block["lines"]:
            if "spans" in line and line["spans"]:
                span = line["spans"][0]
                font_name = span.get("font", "")
                font_size = span.get("size", 0.0)
                font_flags = span.get("flags", 0)
                
                # Check if font is bold (flag 16 indicates bold)
                is_bold = bool(font_flags & 16)
                
                return font_name, font_size, is_bold
        
        return "", 0.0, False
    
    def calculate_heading_score(self, font_size: float, is_bold: bool, 
                              avg_font_size: float, max_font_size: float) -> float:
        """Calculate a score for potential headings based on font properties."""
        if font_size <= 0 or avg_font_size <= 0:
            return 0.0
        
        # Base score from font size relative to average
        size_ratio = font_size / avg_font_size
        size_score = min(size_ratio, 3.0)  # Cap at 3x average
        
        # Bonus for bold text
        bold_bonus = 0.5 if is_bold else 0.0
        
        # Bonus for larger fonts relative to maximum
        if max_font_size > 0:
            max_ratio = font_size / max_font_size
            max_bonus = max_ratio * 0.3
        else:
            max_bonus = 0.0
        
        return size_score + bold_bonus + max_bonus
    
    def classify_heading_level(self, score: float, font_size: float, 
                             title_font_size: float) -> Optional[str]:
        """Classify text as H1, H2, or H3 based on score and font size."""
        # Don't classify as heading if font size is too close to title
        if title_font_size > 0 and font_size >= title_font_size * 0.9:
            return None
        
        # Minimum score threshold for headings
        if score < 1.3:
            return None
        
        # Classify based on score ranges
        if score >= 2.0:
            return "H1"
        elif score >= 1.7:
            return "H2"
        elif score >= 1.3:
            return "H3"
        
        return None
    
    def extract_title(self, doc: fitz.Document) -> str:
        """Extract document title from the first page (largest font)."""
        if len(doc) == 0:
            return "Untitled Document"
        
        page = doc[0]
        blocks = page.get_text("dict")["blocks"]
        
        title_text = ""
        max_font_size = 0.0
        
        for block in blocks:
            if "lines" not in block:
                continue
            
            for line in block["lines"]:
                if "spans" not in line:
                    continue
                
                for span in line["spans"]:
                    font_size = span.get("size", 0.0)
                    text = span.get("text", "").strip()
                    
                    if font_size > max_font_size and text and len(text) > 3:
                        max_font_size = font_size
                        title_text = text
        
        return title_text if title_text else "Untitled Document"
    
    def extract_headings(self, doc: fitz.Document, title_font_size: float) -> List[Dict]:
        """Extract headings from all pages of the document."""
        headings = []
        
        # First pass: collect all font sizes to calculate statistics
        all_font_sizes = []
        text_blocks = []
        
        for page_num in range(len(doc)):
            page = doc[page_num]
            blocks = page.get_text("dict")["blocks"]
            
            for block in blocks:
                if "lines" not in block:
                    continue
                
                # Extract text and font info from block
                block_text = ""
                font_name, font_size, is_bold = self.get_font_info(block)
                
                for line in block["lines"]:
                    if "spans" in line:
                        line_text = "".join(span.get("text", "") for span in line["spans"])
                        block_text += line_text + " "
                
                block_text = block_text.strip()
                
                if block_text and font_size > 0:
                    all_font_sizes.append(font_size)
                    text_blocks.append({
                        "text": block_text,
                        "font_size": font_size,
                        "is_bold": is_bold,
                        "page": page_num + 1
                    })
        
        if not all_font_sizes:
            return headings
        
        # Calculate font size statistics
        avg_font_size = sum(all_font_sizes) / len(all_font_sizes)
        max_font_size = max(all_font_sizes)
        
        # Second pass: identify headings based on font properties
        for block_info in text_blocks:
            text = block_info["text"]
            font_size = block_info["font_size"]
            is_bold = block_info["is_bold"]
            page_num = block_info["page"]
            
            # Skip very long text (likely paragraphs)
            if len(text) > 200:
                continue
            
            # Skip very short text
            if len(text.strip()) < 3:
                continue
            
            # Calculate heading score
            score = self.calculate_heading_score(
                font_size, is_bold, avg_font_size, max_font_size
            )
            
            # Classify heading level
            level = self.classify_heading_level(score, font_size, title_font_size)
            
            if level:
                # Clean up text (remove extra whitespace, newlines)
                clean_text = " ".join(text.split())
                
                headings.append({
                    "level": level,
                    "text": clean_text,
                    "page": page_num
                })
        
        # Sort headings by page number and font size (descending)
        headings.sort(key=lambda x: (x["page"], -text_blocks[0]["font_size"]))
        
        return headings
    
    def process_pdf(self, pdf_path: Path) -> Dict:
        """Process a single PDF file and extract title and headings."""
        try:
            doc = fitz.open(str(pdf_path))
            
            # Extract title
            title = self.extract_title(doc)
            
            # Get title font size for heading classification
            title_font_size = 0.0
            if len(doc) > 0:
                page = doc[0]
                blocks = page.get_text("dict")["blocks"]
                for block in blocks:
                    _, font_size, _ = self.get_font_info(block)
                    if font_size > title_font_size:
                        title_font_size = font_size
            
            # Extract headings
            headings = self.extract_headings(doc, title_font_size)
            
            doc.close()
            
            return {
                "title": title,
                "outline": headings
            }
            
        except Exception as e:
            print(f"Error processing {pdf_path}: {str(e)}")
            return {
                "title": f"Error processing {pdf_path.name}",
                "outline": []
            }
    
    def process_all_pdfs(self):
        """Process all PDF files in the input directory."""
        self.ensure_directories()
        
        pdf_files = list(self.input_dir.glob("*.pdf"))
        
        if not pdf_files:
            print(f"No PDF files found in {self.input_dir}")
            return
        
        print(f"Found {len(pdf_files)} PDF files to process")
        
        for pdf_file in pdf_files:
            start_time = time.time()
            print(f"Processing: {pdf_file.name}")
            
            # Process PDF
            result = self.process_pdf(pdf_file)
            
            # Save result as JSON
            output_filename = f"{pdf_file.stem}.json"
            output_path = self.output_dir / output_filename
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
            
            processing_time = time.time() - start_time
            print(f"Completed: {pdf_file.name} -> {output_filename} ({processing_time:.2f}s)")
            print(f"  Title: {result['title']}")
            print(f"  Headings found: {len(result['outline'])}")


def main():
    """Main entry point for the CLI tool."""
    print("Adobe PDF CLI Tool - Connecting the Dots Challenge")
    print("=" * 50)
    
    processor = PDFProcessor()
    
    try:
        processor.process_all_pdfs()
        print("\nProcessing completed successfully!")
    except KeyboardInterrupt:
        print("\nProcessing interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\nError: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
